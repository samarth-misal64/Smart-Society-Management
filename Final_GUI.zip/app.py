import sys
from typing_extensions import Self
from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QDialog, QApplication
from Ui_ui_main import *

ex = Ui_MainWindow()

#################################################
#         PAGES LINKING SUB FUNCTIONS           #
#################################################

def home():
    ex.stackedWidget.setCurrentIndex(0)
def manage_society():
    ex.stackedWidget.setCurrentIndex(1)

def whatsapp_notice():
    ex.stackedWidget.setCurrentIndex(2)

def complaint_forum():
    ex.stackedWidget.setCurrentIndex(3)

def about():
    ex.stackedWidget.setCurrentIndex(4)

def owner():
    ex.stackedWidget_home.setCurrentIndex(0)

def staff():
    ex.stackedWidget_home.setCurrentIndex(1)

def member():
    ex.stackedWidget_home.setCurrentIndex(2)

def vehicle():
    ex.stackedWidget_home.setCurrentIndex(3)

#################################################
#            MAIN LINKING FUNCTIONS             #
#################################################

def connect_pages():
    ex.bn_home.clicked.connect(home)
    ex.bn_manage_society.clicked.connect(manage_society)
    ex.bn_whatsapp_notice.clicked.connect(whatsapp_notice)
    ex.bn_complaint_forum.clicked.connect(complaint_forum)
    ex.bn_about.clicked.connect(about)

    ex.sub_btn_owner.clicked.connect(owner)
    ex.sub_btn_staff.clicked.connect(staff)
    ex.sub_btn_member.clicked.connect(member)
    ex.sub_btn_vehicle.clicked.connect(vehicle)
    
##################################################

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    w = QtWidgets.QMainWindow()
    ex.setupUi(w)

    # CALL TO LINK PAGES
    connect_pages()

    w.show()
    sys.exit(app.exec_())
    




# class AppWindow(QDialog):
#     def __init__(self):
#         super().__init__()
#         self.ui = Ui_MainWindow()
#         self.ui.setupUi(self)
#         self.show()  

# app = QApplication(sys.argv)
# w = AppWindow()
# w.show()
# sys.exit(app.exec_())